import logging
import os

import subprocess
from buildpack import util

NEWRELIC_INSTALL_PATH = os.path.abspath(".local/newrelic/")
NEWRELIC_JAVAAGENT_PATH = os.path.join(NEWRELIC_INSTALL_PATH, "newrelic.jar")


CF_APPLICATION_INDEX = int(os.getenv("CF_INSTANCE_INDEX", default="0"))
CF_APPLICATION_NAME = util.get_vcap_data()["application_name"]

NEWRELIC_ENV_VARS = {
    "NEWRELIC_AGENT_APPLICATION_NAME": os.getenv("NEW_RELIC_LICENSE_KEY")
}


def _set_default_env(m2ee):
    for var_name, value in NEWRELIC_ENV_VARS.items():
        util.upsert_custom_environment_variable(m2ee, var_name, value)


def stage(buildpack_dir, destination_path, cache_path):
    if newrelic_used():
        util.resolve_dependency(
            "newrelic.agent",
            # destination_path - DOT_LOCAL_LOCATION
            destination_path + "/newrelic/",
            buildpack_dir=buildpack_dir,
            cache_dir=cache_path,
        )


def update_config(m2ee):
    if not newrelic_used():
        return

    if not _is_javaagent_installed():
        logging.warning(
            "NewRelic Java Agent isn't installed yet. "
            "Please redeploy your application to complete "
            "NewRelic Java Agent installation."
        )
        return

    logging.info("NewRelic Java Agent env. variables are configured. Starting...")

    util.upsert_javaopts(
        m2ee,
        [
            f"-newrelic:{NEWRELIC_JAVAAGENT_PATH}",
            f"-newrelic.install.dir={NEWRELIC_INSTALL_PATH}",
        ],
    )

    _set_default_env(m2ee)


def run():
    if not _is_javaagent_installed():
        return

    if not _is_javaagent_installed():
        logging.warning(
            "NewRelic Java Agent isn't installed yet. "
            "Please redeploy your application to complete "
            "NewRelic Java Agent installation."
        )
        return

    logging.info("NewRelic Machine Agent env. variable is configured. Starting...")
    env_dict = dict(os.environ)
    env_dict.update(NEWRELIC_ENV_VARS)


def _is_javaagent_installed():
    return os.path.exists(NEWRELIC_JAVAAGENT_PATH)


def newrelic_used():
    """
    The function checks if all required NewRelic related
    environment variables are set.

    """
    required_envs = {
        "NEW_RELIC_LICENSE_KEY",
    }

    os_env_set = set(os.environ)

    diff_envs = required_envs.difference(os_env_set)

    if len(diff_envs) == 0:
        return True
    return False

