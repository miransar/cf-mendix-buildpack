import logging
import os

import backoff
import socket
import subprocess
from buildpack import util

NAMESPACE = "newrelic"
ROOT_DIR = ".local"
LOGS_PORT = 9032


def stage(buildpack_dir, install_path, cache_path):
    if get_new_relic_license_key():
        util.resolve_dependency(
            f"{NAMESPACE}.agent",
            _get_destination_dir(install_path),
            buildpack_dir=buildpack_dir,
            cache_dir=cache_path,
        )


def _get_destination_dir(dot_local=ROOT_DIR):
    return os.path.abspath(os.path.join(dot_local, NAMESPACE))


def update_config(m2ee, app_name):
    if get_new_relic_license_key() is None:
        logging.debug("Skipping New Relic setup, no license key found in environment")
        return
    logging.info("Adding new relic")

    util.upsert_custom_environment_variable(
        m2ee, "NEW_RELIC_LICENSE_KEY", get_new_relic_license_key()
    )
    util.upsert_custom_environment_variable(m2ee, "NEW_RELIC_APP_NAME", app_name)
    util.upsert_custom_environment_variable(
        m2ee,
        "NEW_RELIC_LOG",
        os.path.join(_get_destination_dir(), "newrelic", "agent.log"),
    )

    util.upsert_javaopts(
        m2ee,
        f"-javaagent:{os.path.join(_get_destination_dir(), 'newrelic', 'newrelic.jar')}",  # noqa: line-too-long
    )


def get_new_relic_license_key():
    vcap_services = util.get_vcap_services_data()
    if vcap_services and "newrelic" in vcap_services:
        return vcap_services["newrelic"][0]["credentials"]["licenseKey"]
    return None


def is_enabled():
    return get_new_relic_license_key() is not None


def _is_installed():
    return os.path.exists(_get_agent_dir())


def _get_agent_dir(root=ROOT_DIR):
    return os.path.join(root, NAMESPACE, "lib")


def _set_up_environment(model_version, runtime_version):
    e = dict(os.environ.copy())

    # Everything in New Relic.yaml can be configured with environment variables
    # This is the "official way" of working with the DD buildpack
    # so let's do this to ensure forward compatibility
    # Trace variables need to be set in the global environment
    # since the New Relic Java Trace Agent does not live inside the New Relic Agent process
    e["NEW_RELIC_LICENSE_KEY"] = get_new_relic_license_key()

    return e

def run(model_version, runtime_version):
    if not is_enabled():
        return

    if not _is_installed():
        logging.warning(
            "New Relic Agent isn't installed yet but DD_API_KEY is set."
            "Please push or restage your app to complete New Relic installation."
        )
        return

    logging.debug("Setting New Relic Agent script permissions if required...")
    util.set_executable(f"{_get_agent_dir()}/*.sh")

    # Start the run script "borrowed" from the official DD buildpack
    # and include settings as environment variables
    logging.info("Starting New Relic Agent...")

    agent_environment = _set_up_environment(model_version, runtime_version)
    logging.debug("New Relic Agent environment variables: [%s]", agent_environment)

    subprocess.Popen(
        os.path.join(_get_agent_dir(), "run-New Relic.sh"), env=agent_environment
    )

    # The runtime does not handle a non-open logs endpoint socket
    # gracefully, so wait until it's up
    @backoff.on_predicate(backoff.expo, lambda x: x > 0, max_time=10)
    def _await_logging_endpoint():
        return socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect_ex(
            ("localhost", LOGS_PORT)
        )

    logging.info("Awaiting New Relic Agent log subscriber...")
    if _await_logging_endpoint() == 0:
        logging.info("New Relic Agent log subscriber is ready")
    else:
        logging.error(
            "New Relic Agent log subscriber was not initialized correctly."
            "Application logs will not be shipped to New Relic."
        )